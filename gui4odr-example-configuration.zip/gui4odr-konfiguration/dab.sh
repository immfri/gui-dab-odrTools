#!/bin/bash

killall screen
killall -9 screen
find . -maxdepth 1 -type p -delete
mkfifo pad-SC-Livestream-BigFM.fifo
mkfifo ./eti.fifo
screen -dm -S dablin dablin_gtk ./eti.fifo
sleep 2

screen -dm -S padenc-SC-Livestream-BigFM odr-padenc -t ./bigfm-sources/dls-bigfm-live.txt -c 15 -d ./bigfm-sources/sls-bigfm-live -s 2 -p 58 -o pad-SC-Livestream-BigFM.fifo
screen -dm -S audioenc-SC-AnalogIN odr-audioenc -j analog-IN -b 96 -c 2 -r 48000 -a -o tcp://localhost:9000 
screen -dm -S audioenc-SC-DigitalIN odr-audioenc -j digital-IN -b 96 -c 2 -r 48000 -o tcp://localhost:9002 
screen -dm -S audioenc-SC-Livestream-BigFM odr-audioenc -v http://streams.bigfm.de/bigfm-hotmusicradio-128-aac -b 96 -c 2 -r 48000 -a -P pad-SC-Livestream-BigFM.fifo -p 58 -o tcp://localhost:9001 

sleep 2


screen -dm -S dabmux odr-dabmux -e dab.mux

sudo nice -n 5 screen -dm -S USRP-N200 odr-dabmod -C USRP-N200.ini
sudo nice -n 5 screen -dm -S USRP-B100 odr-dabmod -C USRP-B100.ini